---
Creation_date: <% tp.file.creation_date() %>
Modification_date: <% tp.file.last_modified_date("dddd Do MMMM YYYY HH:mm:ss") %>
Indexes:
---
<% tp.file.rename("ENG - ") %>

----
























---
## Flash cards section
